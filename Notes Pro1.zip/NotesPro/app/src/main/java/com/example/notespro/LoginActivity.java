package com.example.notespro;

import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {

    EditText emailEditText;
    EditText passwordEditText;
    Button loginBtn;
    ProgressBar progressBar;
    TextView createAccountBtnTextview;

    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);

        // Handling edge-to-edge layout
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize views
        emailEditText = findViewById(R.id.email_Edit_Text);
        passwordEditText = findViewById(R.id.password_edit_text);
        loginBtn = findViewById(R.id.login_btn);
        progressBar = findViewById(R.id.progress_bar);
        createAccountBtnTextview = findViewById(R.id.create_account_view_btn);

        // Initialize FirebaseAuth
        firebaseAuth = FirebaseAuth.getInstance();

        // Set up button click listeners
        loginBtn.setOnClickListener(v -> loginUser());
        createAccountBtnTextview.setOnClickListener(v -> startActivity(new Intent(LoginActivity.this, CreateAccountActivity.class)));
    }

    // Method to handle login
    void loginUser() {
        String email = emailEditText.getText().toString().trim();

        String password = passwordEditText.getText().toString().trim();


        // Validate input data
        boolean isValid = validateData(email, password);
        if (!isValid) {
            return;
        }

        // Call Firebase method to log the user in
        loginAccountInFirebase(email, password);
    }

    // Method to handle Firebase login
    void loginAccountInFirebase(String email, String password) {
        changeInProgress(true); // Show progress bar

        firebaseAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(this, new OnCompleteListener<AuthResult>()  {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                changeInProgress(false); // Hide progress bar

                if (task.isSuccessful()) {
                    // Check if email is verified
                    if (firebaseAuth.getCurrentUser().isEmailVerified()) {
                        startActivity(new Intent(LoginActivity.this, MainActivity.class));
                        finish(); // Finish this activity after successful login
                    } else {
                        // Show email verification message
                        Toast.makeText(LoginActivity.this, "Email not verified. Please verify your email.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    // Show error message
                    Toast.makeText(LoginActivity.this, task.getException().getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Method to change progress bar visibility
    void changeInProgress(boolean inProgress) {
        if (inProgress) {
            progressBar.setVisibility(View.VISIBLE);
            loginBtn.setVisibility(View.GONE);
        } else {
            progressBar.setVisibility(View.GONE);
            loginBtn.setVisibility(View.VISIBLE);
        }
    }

    // Method to validate email and password input
    boolean validateData(String email, String password) {
        // Check if email matches the correct pattern
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            emailEditText.setError("Email is invalid");
            return false;
        }

        // Check if password length is valid
        if (password.length() < 6) {
            passwordEditText.setError("Password must be at least 6 characters");
            return false;
        }

        return true;
    }

}
