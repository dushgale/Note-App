package com.example.notespro;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.app.ProgressDialog;
import androidx.appcompat.app.AlertDialog;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentReference;

public class NoteDetailsActivity extends AppCompatActivity {

    EditText titleEditText, contentEditText;
    ImageButton saveNoteBtn;
    TextView pageTitleTextView, deleteNoteTextViewBtn;
    String title, content, docId;
    boolean isEditMode = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_note_details);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize views
        titleEditText = findViewById(R.id.note_title);
        contentEditText = findViewById(R.id.note_description);
        saveNoteBtn = findViewById(R.id.save_note_btn);
        pageTitleTextView = findViewById(R.id.page_title);
        deleteNoteTextViewBtn = findViewById(R.id.delete_note_text_view_btn);

        // Get data from intent
        title = getIntent().getStringExtra("title");
        content = getIntent().getStringExtra("content");
        docId = getIntent().getStringExtra("docId");

        // Set edit mode if docId exists
        if (docId != null && !docId.isEmpty()) {
            isEditMode = true;
            pageTitleTextView.setText("Edit your note");
            deleteNoteTextViewBtn.setVisibility(View.VISIBLE);
        }

        // Set text content
        if (title != null) titleEditText.setText(title);
        if (content != null) contentEditText.setText(content);

        // Set click listeners
        saveNoteBtn.setOnClickListener(v -> saveNote());

        if (deleteNoteTextViewBtn != null) {
            deleteNoteTextViewBtn.setOnClickListener(v -> deleteNoteFromFirebase());
        }
    }

    void saveNote() {
        String noteTitle = titleEditText.getText().toString();
        String noteContent = contentEditText.getText().toString();

        if (noteTitle == null || noteTitle.isEmpty()) {
            titleEditText.setError("Title is required");
            return;
        }

        Note note = new Note();
        note.setTitle(noteTitle);
        note.setContent(noteContent);
        note.setTimestamp(Timestamp.now());

        saveNoteToFirebase(note);
    }

    void saveNoteToFirebase(Note note) {
        DocumentReference documentReference;

        if (isEditMode) {
            documentReference = Utility.getCollectionReferenceForNotes().document(docId);
        } else {
            documentReference = Utility.getCollectionReferenceForNotes().document();
        }

        documentReference.set(note).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Utility.showToast(NoteDetailsActivity.this, "Note saved successfully");
                finish();
            } else {
                Utility.showToast(NoteDetailsActivity.this, "Failed while saving note");
            }
        });
    }

    void deleteNoteFromFirebase() {
        if (docId == null || docId.isEmpty()) {
            Utility.showToast(this, "Error: No document ID found");
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle("Delete Note")
                .setMessage("Are you sure you want to delete this note?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    // Show progress dialog
                    ProgressDialog progress = new ProgressDialog(this);
                    progress.setMessage("Deleting note...");
                    progress.show();

                    DocumentReference documentReference =
                            Utility.getCollectionReferenceForNotes().document(docId);

                    documentReference.delete()
                            .addOnCompleteListener(task -> {
                                progress.dismiss();
                                if (task.isSuccessful()) {
                                    Utility.showToast(NoteDetailsActivity.this,
                                            "Note deleted successfully");
                                    finish();
                                } else {
                                    String error = task.getException() != null ?
                                            task.getException().getMessage() : "Unknown error";
                                    Utility.showToast(NoteDetailsActivity.this,
                                            "Failed to delete note: " + error);
                                }
                            });
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}